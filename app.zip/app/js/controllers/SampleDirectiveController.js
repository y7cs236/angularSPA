/**
 * Created by kalyan on 22-04-2016.
 */
'use strict';

eventsApp.controller('SampleDirectiveController',function ($scope) {
    
})