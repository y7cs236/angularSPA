/**
 * Created by kalyan on 19-04-2016.
 */
'use strict';
eventsApp.controller('EventListController',
    function ($scope) {
        $scope.events = [
            {
                id:1,
                name: 'Angular boot Camp',
                Date: 1359781015626,
                Time: '11:30',
                location: {
                    Address:'Gachibowli',
                    City: 'Hyderabad',
                    PinCode: '500084'
                }
            },
            {
                id:2,
                name: 'Linq Mastering',
                Date: 1359781015626,
                Time: '11:30',
                location: {
                    Address:'Vengaiah Nagar',
                    City: 'Guntur',
                    PinCode: '522002'
                }
            },
            {
                id:3,
                name: 'Jquery Dummies',
                Date: 1359781015626,
                Time: '11:30',
                location: {
                    Address:'sataya puram',
                    City: 'Vijayawada',
                    PinCode: '520102'
                }
            },
            {
                id:4,
                name: 'WCF Fundamentals',
                Date: 1359781015626,
                Time: '11:30',
                location: {
                    Address:'Koretapadu',
                    City: 'Guntur',
                    PinCode: '520102'
                }
            }
        ];
    });