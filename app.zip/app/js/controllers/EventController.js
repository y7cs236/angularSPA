"use strict";

eventsApp.controller('EventController',
    function ($scope,EventsData,$routeParams,$route) {

        $scope.sortOrder = 'name';
        $scope.boolvalue = true;
        $scope.message = 'test';
        $scope.mystyle = {color: 'red'};
        $scope.myclass = "blue";
        $scope.MaxCount='4';

        $scope.reload=function () {
            $route.reload();
        };

        $scope.event = EventsData.getEventDetails($routeParams.eventId);

        $scope.upVotesession = function (session) {
            session.VoteCount++;
        }
        $scope.DownVotesession = function (session) {
            session.VoteCount--;
        }
    }
);