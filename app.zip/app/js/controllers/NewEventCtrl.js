/**
 * Created by kalyan on 09-04-2016.
 */
'use strict';

eventsApp.controller('newEventCtrl',
    function ($scope) {
console.log('inside newEventctrl');
        $scope.SaveEventDetails=function(event, newEventForm){
            if(newEventForm.$valid) {
                window.alert(event.name + ' is saved successfully');
            }
        }
    }
);