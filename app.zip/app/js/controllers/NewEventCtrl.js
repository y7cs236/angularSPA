/**
 * Created by kalyan on 09-04-2016.
 */
'use strict';

eventsApp.controller('newEventCtrl',
    function ($scope) {

        $scope.SaveEventDetails=function(event, newEventForm){
            if(newEventForm.$valid) {
                window.alert(event.name + ' is saved successfully');
            }
        }
    }
);