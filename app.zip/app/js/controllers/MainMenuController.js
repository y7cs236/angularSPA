/**
 * Created by kalyan on 22-04-2016.
 */
'use strict';

eventsApp.controller('MainMenuController',
    function MainMenuController($scope,$location) {


        $scope.CreateEvent = function () {
            $location.replace();
            $location.url('newEvent');
        };

        $scope.EditProfile = function () {
            console.log('inside edit profile link');
            $location.url('EditProfile');
        }

    });
