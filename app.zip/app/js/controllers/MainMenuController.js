/**
 * Created by kalyan on 22-04-2016.
 */
'use strict';

eventsApp.controller('MainMenuController',
    function MainMenuController($scope,$location) {


        $scope.CreateEvent = function () {
            $location.replace();
            $location.url('newEvent');
        };

        $scope.Event = function () {
            $location.url('Events');
        };
        $scope.EditProfile = function () {
            console.log('inside edit profile1 link');
            $location.url('EditProfile');
        };

    });
