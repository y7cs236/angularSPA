'use strict';

eventsApp.directive('mySample',function () {
    return{
        restrict :'A',
        template : "<input type='text' ng-model='data'>{{data}}<br/>",
        scope:
        {
            
        }
    };
})