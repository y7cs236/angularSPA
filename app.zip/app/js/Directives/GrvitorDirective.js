/**
 * Created by kalyan on 22-04-2016.
 */
'use strict';

eventsApp.directive('gravatar',function (gravatarUrlBuilder) {
    return{
        restrict : 'E',
        replace: true,
        template : '<img />',
        link:function (scope,element,attrs,controller) {
            attrs.$observe('email',function (newValue ,oldValue) {
                console.log('old value'+ oldValue!==newValue);
                console.log('new value'+ newValue);
                console.log('gravatar value'+ gravatarUrlBuilder.buildGravatarUrl(newValue));
                if(oldValue!==newValue)
                {
                    attrs.$set('src',gravatarUrlBuilder.buildGravatarUrl(newValue));
                }
            });
        }
    };
})