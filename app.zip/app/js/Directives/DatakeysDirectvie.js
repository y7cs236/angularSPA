/**
 * Created by kalyan on 22-04-2016.
 */
'use strict';

eventsApp.directive('dateKeys',function () {
    return{
        restrict : 'A',
        link: function (scope,element,attrs,controller) {
           element.on('keydown',function (event) {
               console.log(event.keyCode);
               if(isNumericKeycode(event.keyCode)||isForwardSlashKeycode(event.keyCode)||isNavigationKeycode(event.keyCode))
               {
                   return true;
               }
               return false;
           })
        }
    }

    function isNumericKeycode(keyCode) {
        return(event.keyCode >=48 && event.keyCode<=57)||
            (event.keyCode >=96 && event.keyCode<=105);
    }
    function isForwardSlashKeycode(keyCode) {
        return event.keyCode===191;
    }
    function  isNavigationKeycode(keyCode) {
        switch (keyCode)
        {
            case 8:
            case 35:
            case 36:
            case 37:
            case 38:
            case 39:
            case 40:
            case 45:
            case 46:
                return true;
            default:
                return false;
        }
    }

});
