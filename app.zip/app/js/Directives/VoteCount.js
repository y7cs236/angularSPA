/**
 * Created by kalyan on 22-04-2016.
 */
'use strict';

eventsApp.directive('voteCount',function () {
    return{
        restrict : 'E',
        replace: true,
        templateUrl : '/templates/directives/VoteCount.html',
        scope :
        {
            upvote :'&',
            downvote :'&',
            count :'='
        }
    };
})