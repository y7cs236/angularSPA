/**
 * Created by kalyan on 22-04-2016.
 */
'use strict';

eventsApp.directive('eventSample',function () {
    return{
        restrict : 'E',
        replace: true,
        templateUrl : '/templates/directives/EventThumbnails.html',
        scope:{
            event:'='
        }
    };
})