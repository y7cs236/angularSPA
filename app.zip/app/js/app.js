'use strict';

var eventsApp = angular.module('eventsApp', ['ngRoute'])
    .config(function($routeProvider,$locationProvider){
    $routeProvider.when('/newEvent',
        {
            templateUrl:'../templates/NewEvent.html',
            controller:'newEventCtrl'
        }
    ).when('/Events',
        {
            templateUrl:'../templates/EventList.html',
            controller:'EventListController'
        })
        .when('/event/:eventId',
            {
                templateUrl:'../templates/EventDetails.html',
                controller:'EventController'
            })
        .when('/EventDetails',
            {
                templateUrl:'../templates/EventDetails.html',
                controller:'EventController'
            })
        .when('/EditProfile',
            {
                templateUrl:'../templates/EditProfile.html',
                controller:'EditProfileController'
            })
        .when('/SampleDirect',
            {
                templateUrl:'../templates/SampleDirective.html',
                controller:'EditProfileController'
            });
       // $routeProvider.otherwise({redirectTo:'/EventDetails'});
        $locationProvider.html5Mode(true);
});