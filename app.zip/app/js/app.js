'use strict';

var eventsApp = angular.module('eventsApp', ['ngRoute'])
    .config(function($routeProvider,$locationProvider){
    $routeProvider.when('/newEvent',
        {
            templateUrl:'../templates/NewEvent.html',
            controller:'newEventCtrl'
        }
    ).when('/Events',
        {
            templateUrl:'../templates/EventList.html',
            controller:'EventListController'
        })
        .when('/event/:eventId',
            {
                test:'this is test',
                templateUrl:'../templates/EventDetails.html',
                controller:'EventController'
            })
        .when('/EventDetails',
            {
                templateUrl:'../templates/EventDetails.html',
                controller:'EventController'
            });
        $routeProvider.otherwise({redirectTo:'/Events'});
        $locationProvider.html5Mode(true);
});