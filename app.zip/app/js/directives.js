'use strict';

eventsApp.directive('mySample',function () {
    return{
        template : "<input type='text' ng-model='data'>{{data}}<br/>"
    };
})