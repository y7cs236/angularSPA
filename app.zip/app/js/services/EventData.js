/**
 * Created by kalyan on 15-04-2016.
 */
'use strict';
eventsApp.factory('EventsData',function ($http,$log) {
    return{
       getEventDetails:function (id) {

               switch(parseInt(id)) {
                   case 1:
                       return {
                           id: 1,
                           name: 'Angular boot Camp',
                           Date: 1359781015626,
                           Time: '11:30',
                           location: {
                               Address: 'Gachibowli',
                               City: 'Hyderabad',
                               PinCode: '500084'
                           }, Sessions:[
                               {
                                   name : 'Mastering Web API',
                                   CreatorName: 'Gopala Krishna',
                                   Duration : 1,
                                   level:'Advanced',
                                   VoteCount:8
                               },
                               {
                                   name : 'Programming with WCF',
                                   CreatorName: 'udayagiri  kalayn',
                                   Duration : 2,
                                   level:'Beginner',
                                   VoteCount:2
                               },
                               {
                                   name : 'Jquery Guide',
                                   CreatorName: 'Gopala Krishna',
                                   Duration : 6,
                                   level:'Advanced',
                                   VoteCount:6
                               }

                           ]
                       };
                       break;
                   case 2:
                       return {
                           id:2,
                           name: 'Linq Mastering',
                           Date: 1359781015626,
                           Time: '11:30',
                           location: {
                               Address:'Vengaiah Nagar',
                               City: 'Guntur',
                               PinCode: '522002'
                           }, Sessions:[
                               {
                                   name : 'Mastering Web API',
                                   CreatorName: 'Gopala Krishna',
                                   Duration : 1,
                                   level:'Advanced',
                                   VoteCount:8
                               },
                               {
                                   name : 'Programming with WCF',
                                   CreatorName: 'udayagiri  kalayn',
                                   Duration : 2,
                                   level:'Beginner',
                                   VoteCount:2
                               },
                               {
                                   name : 'Jquery Guide',
                                   CreatorName: 'Gopala Krishna',
                                   Duration : 6,
                                   level:'Advanced',
                                   VoteCount:6
                               }

                           ]
                       };
                       break;
                   case 3:
                       return  {
                           id:3,
                           name: 'Jquery Dummies',
                           Date: 1359781015626,
                           Time: '11:30',
                           location: {
                               Address:'sataya puram',
                               City: 'Vijayawada',
                               PinCode: '520102'
                           }, Sessions:[
                               {
                                   name : 'Mastering Web API',
                                   CreatorName: 'Gopala Krishna',
                                   Duration : 1,
                                   level:'Advanced',
                                   VoteCount:8
                               },
                               {
                                   name : 'Programming with WCF',
                                   CreatorName: 'udayagiri  kalayn',
                                   Duration : 2,
                                   level:'Beginner',
                                   VoteCount:2
                               },
                               {
                                   name : 'Jquery Guide',
                                   CreatorName: 'Gopala Krishna',
                                   Duration : 6,
                                   level:'Advanced',
                                   VoteCount:6
                               }

                           ]
                       };
                       break;
                   case 4:
                       return {
                           id:4,
                           name: 'WCF Fundamentals',
                           Date: 1359781015626,
                           Time: '11:30',
                           location: {
                               Address: 'Koretapadu',
                               City: 'Guntur',
                               PinCode: '520102'
                           }, Sessions:[
                               {
                                   name : 'Mastering Web API',
                                   CreatorName: 'Gopala Krishna',
                                   Duration : 1,
                                   level:'Advanced',
                                   VoteCount:8
                               },
                               {
                                   name : 'Programming with WCF',
                                   CreatorName: 'udayagiri  kalayn',
                                   Duration : 2,
                                   level:'Beginner',
                                   VoteCount:2
                               },
                               {
                                   name : 'Jquery Guide',
                                   CreatorName: 'Gopala Krishna',
                                   Duration : 6,
                                   level:'Advanced',
                                   VoteCount:6
                               }

                           ]
                       };
                       break;
                   default:
                       console.log('inside switch default');
               }

           }
           
       }
});   